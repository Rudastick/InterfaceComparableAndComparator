package pl.kurs.homework02.app;

public class ComputerRunner {
    public static void main(String[] args) {
        //tutaj wstawiłbym porównanie ale tak bardzo nie chce mi sie tworzyć tych objektów gdybym mial wersje ultimate to bym poprosil chatgpt aby mi to wygenerował a tak to sie poddaje....................
    }
}
